<!--Theepana-->

function function1()
{
var name = prompt("Enter your email address");
}


var count=1;
function next()
{
if (count<=15)
{
count++;
document.getElementById("img1").src="images/"+count+".jpg";
document.getElementById("img2").src="images/"+(count+1)+".jpg";
document.getElementById("img3").src="images/"+(count+2)+".jpg";
}
}
function prev()
{
if (count>1)
{
count--;
document.getElementById("img1").src="images/"+count+".jpg";
document.getElementById("img2").src="images/"+(count+1)+".jpg";
document.getElementById("img3").src="images/"+(count+2)+".jpg";
}
}


function func()
{
if(document.getElementById("change").type=="text")
{
document.getElementById("change").type="password";
}
else
{
document.getElementById("change").type="text";
}
}


var count=1;
function next1()
{
if (count<=9)
{
count++;
document.getElementById("img1").src="images/photo"+count+".jpg";
document.getElementById("img2").src="images/photo"+(count+1)+".jpg";
document.getElementById("img3").src="images/photo"+(count+2)+".jpg";
}
}
function prev1()
{
if (count>1)
{
count--;
document.getElementById("img1").src="images/photo"+count+".jpg";
document.getElementById("img2").src="images/photo"+(count+1)+".jpg";
document.getElementById("img3").src="images/photo"+(count+2)+".jpg";
}
}

function func1()
{
if((document.getElementById("text").value=="theepana") && (document.getElementById("password").value="Theepana1@"))
{
location.href="adddetails.html";
}
else
{
alert("Invalid login");
}
}
